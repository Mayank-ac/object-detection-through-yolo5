# ModifiedOpenLabelling
A modified version of https://github.com/Cartucho/OpenLabeling OpenLabelling tool.

This repo is used as an example labelling tool in the [YOLOv5 Series](https://www.youtube.com/playlist?list=PLD80i8An1OEHEpJVjtujEb0lQWc0GhX_4).

![](https://user-images.githubusercontent.com/41416855/122698979-26331d00-d251-11eb-8d02-f4b479e8c0df.png)


